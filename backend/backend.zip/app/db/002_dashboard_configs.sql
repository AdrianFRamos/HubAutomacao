-- Migration: Adicionar tabela dashboard_configs
-- Data: 2025-11-11
-- Descrição: Tabela para armazenar configurações de dashboards do DELPHOS.BI

CREATE TABLE IF NOT EXISTS dashboard_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL UNIQUE,
    display_name VARCHAR(200) NOT NULL,
    description TEXT,
    
    -- Navegação no menu
    menu_path JSONB NOT NULL DEFAULT '[]'::jsonb,
    
    -- Busca visual
    search_text VARCHAR(500),
    search_image VARCHAR(500),
    
    -- Coordenadas (fallback)
    click_coords JSONB,
    menu_coords JSONB,
    
    -- Screenshot
    screenshot_region JSONB NOT NULL DEFAULT '[0, 40, 1920, 1000]'::jsonb,
    
    -- Configuração de período
    has_period_selector BOOLEAN NOT NULL DEFAULT FALSE,
    available_periodicities JSONB NOT NULL DEFAULT '[]'::jsonb,
    
    -- Status
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_dashboard_configs_name ON dashboard_configs(name);
CREATE INDEX IF NOT EXISTS idx_dashboard_configs_is_active ON dashboard_configs(is_active);

-- Comentários
COMMENT ON TABLE dashboard_configs IS 'Configurações de dashboards do sistema DELPHOS.BI';
COMMENT ON COLUMN dashboard_configs.menu_path IS 'Caminho no menu hierárquico, ex: ["Dashboards", "Geradores", "Planilhas"]';
COMMENT ON COLUMN dashboard_configs.search_text IS 'Texto para buscar na lista de dashboards';
COMMENT ON COLUMN dashboard_configs.search_image IS 'Nome do arquivo de imagem de referência';
COMMENT ON COLUMN dashboard_configs.click_coords IS 'Coordenadas de clique {x, y}';
COMMENT ON COLUMN dashboard_configs.menu_coords IS 'Coordenadas dos itens de menu {0: {x, y}, 1: {x, y}, ...}';
COMMENT ON COLUMN dashboard_configs.screenshot_region IS 'Região de captura [x, y, largura, altura]';
COMMENT ON COLUMN dashboard_configs.has_period_selector IS 'Se o dashboard possui seletor de período';
COMMENT ON COLUMN dashboard_configs.available_periodicities IS 'Periodicidades disponíveis: ["diario", "mensal", "anual"]';

-- Dados iniciais (exemplos)
INSERT INTO dashboard_configs (name, display_name, description, menu_path, search_text, screenshot_region, has_period_selector, available_periodicities, is_active)
VALUES 
    (
        'comercial_2024_2025',
        'Comercial - 2024 x 2025',
        'Dashboard comparativo de vendas entre 2024 e 2025',
        '["Dashboards", "Geradores De Dashboards", "Planilhas"]'::jsonb,
        'Comercial - 2024 x 2025 - Homologação - Adrian',
        '[0, 40, 1920, 1000]'::jsonb,
        TRUE,
        '["diario", "mensal", "anual"]'::jsonb,
        TRUE
    ),
    (
        'comercial_comparativo',
        'Comercial - Comparativo',
        'Dashboard comparativo de vendas por período',
        '["Dashboards", "Geradores De Dashboards", "Planilhas"]'::jsonb,
        'Comercial - Comparativo',
        '[0, 40, 1920, 1000]'::jsonb,
        TRUE,
        '["mensal", "anual"]'::jsonb,
        TRUE
    ),
    (
        'comercial_estoque',
        'Comercial - Estoque',
        'Dashboard de controle de estoque',
        '["Dashboards", "Geradores De Dashboards", "Planilhas"]'::jsonb,
        'Comercial - Estoque',
        '[0, 40, 1920, 1000]'::jsonb,
        TRUE,
        '["diario", "mensal"]'::jsonb,
        TRUE
    ),
    (
        'financeiro',
        'Financeiro - Contas a Receber',
        'Dashboard financeiro de contas a receber',
        '["Dashboards", "Geradores De Dashboards", "Planilhas"]'::jsonb,
        'Financeiro - Contas a Receber',
        '[0, 60, 1800, 950]'::jsonb,
        TRUE,
        '["mensal", "anual"]'::jsonb,
        TRUE
    )
ON CONFLICT (name) DO NOTHING;
